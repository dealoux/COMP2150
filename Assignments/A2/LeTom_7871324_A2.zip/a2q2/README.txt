Name: Tom Le
Student ID: 7871324

Compile: make
Execute: ./LeTom_7871324_A2Q2 a2q2.txt

Description:
/**
* LeTomA2Q2.cpp
*
* COMP 2150 SECTION A01
* INSTRUCTOR Riley Wall
* ASSIGNMENT Assignment 2, question 2
* @author Tom Le, 7871324
* @version July 3rd 2022
*
* REMARKS: implementation of the Person/Student/Employee/Instructor/Administrator hierarchy of classes
*/

Platform: Ubuntu 20.4 WSL on Windows 11, VS Code, compiled with clang